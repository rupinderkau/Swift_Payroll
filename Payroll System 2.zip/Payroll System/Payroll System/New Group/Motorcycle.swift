//
//  Motorcycle.swift
//  Payroll System
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Motorcycle : Vehicle
{
    var enginepower : Float
    var topspeed : Float
    
    init (company: String, plate: String, colour: String, year: Int, enginepower: Float, topspeed: Float)
    {
        self.enginepower = enginepower
        self.topspeed = topspeed
        super.init(company: company, plate: plate, colour: colour, year: year)
    }
    
    func display()
        
    {
        
    }
}
