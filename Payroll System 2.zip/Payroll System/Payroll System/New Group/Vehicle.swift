//
//  Vehicle.swift
//  Payroll System
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Vehicle {
    var company: String!
    var plate: String!
    var colour: String!
    var year: Int!
    
    init(company: String, plate: String, colour: String, year: Int)
    {
        self.company = company
        self.plate = plate
        self.colour = colour
    }
    func display() {
        
    }
    
    
}
